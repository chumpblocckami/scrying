"""
Scrying.

A ScryfallAPI port written in Python.
"""

__version__ = "0.0.1"
__author__ = 'Matteo Mazzola'
__credits__ = 'Vedalken'
