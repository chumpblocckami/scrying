Scrying: a ScryfallAPI written in Python

Usage:

> from scrying.main import Scrying
> 
> scry = Scrying()
> 
> scry.download_from_url("f:pauper t:creature t:human c:white")
> 
> scry[126]

N.B: This is used only to retrieve artworks. For personalized or specific requests, open a PR :) 
